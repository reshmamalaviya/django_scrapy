from celery import shared_task
from scraper.scraper.spiders.amazon import AmazonSpider
from scrapy.crawler import CrawlerRunner
from scrapy.utils.project import get_project_settings
from twisted.internet import reactor, defer
import os

@defer.inlineCallbacks
def use(product):
        crawler_settings = get_project_settings()
        crawler = CrawlerRunner(crawler_settings)
        yield crawler.crawl(AmazonSpider, Text=product) 
        reactor.stop()
    
@shared_task()
def sync_asin(product):
    try:
        use(product)
        reactor.run()
        if product is None:
            # I want to call the scrapy spider here.
            os.environ.setdefault("SCRAPY_SETTINGS_MODULE","scraper_pro.scraper.scraper.settings")
      
    except Exception as e:
        pass

