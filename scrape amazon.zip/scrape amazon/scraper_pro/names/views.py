from django.shortcuts import render
from names.tasks import *
from names.models import Amazon


def home(request):
        if request.method =="POST":
                product = request.POST.get('product')
                try:
                        sync_asin.apply_async(args=[product])                        
                except Exception as e:
                        pass
                       # url = 'https://www.amazon.in/s?k='+product
                return render(request, 'home.html')
        else:
                return render(request, 'home.html')

def index(request):
    data = Amazon.objects.all()
    return render(request, 'index.html', {'data':data})