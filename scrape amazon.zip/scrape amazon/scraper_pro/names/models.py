from django.db import models

# Create your models here.


class Amazon(models.Model):
        product_name = models.CharField(max_length=150)
        product_price = models.CharField(max_length=150)
        product_imagelink = models.TextField(blank=True)

        class Meta:
            verbose_name = "amazon"

        def __str__(self):
            return self.product_name