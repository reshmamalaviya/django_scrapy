from django.contrib import admin

from names.models import Amazon

# Register your models here.


admin.site.register(Amazon)