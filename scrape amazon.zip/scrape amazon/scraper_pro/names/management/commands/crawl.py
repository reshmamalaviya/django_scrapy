from django.core.management.base import BaseCommand
from scraper.scraper.spiders.amazon import AmazonSpider
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings

class Command(BaseCommand):
    help = "Release the spiders"

    def add_arguments(self, parser):
         parser.add_argument('my_str_argument', type=str)

    def handle(self, *args, **kwargs):
        e = kwargs['my_str_argument']
        process = CrawlerProcess(get_project_settings())

        demo ={'text' : e}

        process.crawl(AmazonSpider, **demo)
        process.start()

        
