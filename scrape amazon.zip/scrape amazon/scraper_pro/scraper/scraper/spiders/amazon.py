import scrapy
from names.models import Amazon
from ..items import *

class AmazonSpider(scrapy.Spider):
    name = 'amazon'
    allowed_domains = ['amazon.com']
    start_urls = []

    # def __init__(self, **kwargs):
    #     super().__init__(**kwargs)
    #     self.start_urls= [
    #         f'https://www.amazon.in/s?k={self.text}'
    #         ]

    def __init__(self, Text=None):
        self.Text = Text
        url = "https://www.amazon.in/s?k="
        next_url = url + str(Text)
        self.start_urls.append(next_url)

    custom_settings = {
        'FEED_FORMAT' : 'json',
        'FEED_URI' : 'amazon.json',
        'DOWNLOAD_DELAY' : 1,
        'CONCURRENT_REQUESTS_PER_DOMAIN' : 1
    }

    def parse(self, response):

        items = Amazon()

        for product in response.css('.s-border-top'):
            items['product_name'] = product.css('span.a-size-base-plus').css('::text').extract()
            items['product_price'] = product.css('.a-price-whole').css('::text').extract()
            items['product_imagelink'] = product.css('.s-image::attr(srcset)').extract()

            # Amazon.objects.create(product_name = product_name,
            #                  product_price = product_price,
            #                  product_imagelink= product_imagelink)
            
            yield items
            

